@extends('layouts.master')

@section('content')
    <h1>Halaman Beranda</h1>
@endsection
