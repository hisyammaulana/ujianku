@extends('layouts.master')

@section('content')
<div class="container-fluid">
         <h1>Halaman Beranda</h1>

      </div>
@endsection
