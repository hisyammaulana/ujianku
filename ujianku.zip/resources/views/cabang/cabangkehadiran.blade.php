@extends('layouts.master')
@section('title', 'Daftar Siswa')
@section('page-title', 'Halaman Daftar Siswa')

@section('content')
    <h1>Halaman Kehadiran</h1>
@endsection
