<?php $__env->startSection('title', 'Edit Data Sekolah'); ?>
<?php $__env->startSection('page-title', 'Halaman Edit Data Sekolah'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12 col-lg-12">
            <?php if($message = Session::get('warning')): ?>
            <div class="alert text-white bg-warning" role="alert">
                <div class="iq-alert-text">Data Berhasil Diperbaharui!</div>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ri-close-line"></i>
                </button>
            </div>
             <?php endif; ?>
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Edit Data Sekolah</h4>
                    </div>
                </div>
                <div class="iq-card-body">
                    <form method="POST" action="<?php echo e(route('cabang.sekolah.update', $sekolah->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PATCH')); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        <input type="hidden" name="role_id" value="4">
                        <div class="form-group">
                            <label for="email">Nama Sekolah</label>
                            <input type="text" class="form-control" name="name" autofocus required>
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" name="username">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="text" class="form-control" name="password">
                        </div>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ujianku/resources/views/cabang/editsekolah.blade.php ENDPATH**/ ?>