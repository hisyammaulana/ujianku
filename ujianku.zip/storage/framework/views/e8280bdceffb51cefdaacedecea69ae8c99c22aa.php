<?php $__env->startSection('title', 'Daftar Siswa'); ?>
<?php $__env->startSection('page-title', 'Halaman Daftar Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
                  <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                           <div class="iq-header-title">
                              <h4 class="card-title">Daftar Siswa </h4>
                           </div>

                        </div>
                        <div class="iq-card-body">
                           <div class="table-responsive">
                              <table id="example" class="table table-striped table-bordered" style="width:100%">
                       <thead>
                           <tr>
                               <th>No.</th>
                               <th>NISN</th>
                               <th>Nama Siswa</th>
                               <th>No. Ujian</th>
                               <th>Jenis Kelamin</th>
                               <th>Alamat</th>
                               <th>Aksi</th>
                           </tr>
                       </thead>
                       <tbody>
                            <?php if(count($siswas) === 0): ?>
                                <tr>
                                    <td colspan="7" style="text-align: center;">Tidak ada data siswa</td>
                                </tr>
                            <?php elseif(count($siswas) > 0): ?>
                            <?php ($no = 1); ?>
                            <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($siswa->nisn); ?></td>
                                <td><?php echo e($siswa->name); ?></td>
                                <td><?php echo e($siswa->no_ujian); ?></td>
                                <td><?php echo e($siswa->jenis_kelamin); ?></td>
                                <td><?php echo e($siswa->alamat); ?></td>
                                <td>
                                    <a href="" class="btn btn-warning mb-3"><i class="ri-edit-fill pr-0"></i></a>
                                    <a href="" class="btn btn-danger mb-3"><i class="ri-delete-bin-6-line"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                   </table>
                           </div>
                        </div>
                     </div>
            </div>
         </div>

      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hisyam/Documents/Laravel/ujianku/resources/views/sekolah/daftarsiswa.blade.php ENDPATH**/ ?>