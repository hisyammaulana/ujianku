 <?php $__env->startSection('title', 'Kehadiran'); ?> <?php $__env->startSection('page-title', 'Halaman Ketidakhadiran Siswa'); ?> <?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <?php if($message = Session::get('danger')): ?>
            <div class="alert text-white bg-danger" role="alert">
                <div class="iq-alert-text">Data Berhasil Dihaspus!</div>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="ri-close-line"></i>
                </button>
            </div>
             <?php endif; ?>
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Data Siswa yang Tidak Mengikuti Ujian Nasional</h4>
                    </div>
                    <div class="iq-card-header-toolbar d-flex align-items-center">
                        <div class="custom-control custom-switch custom-switch-text custom-control-inline">
                            <div class="custom-switch-inner">
                                <a href="<?php echo e(route('sekolah.kehadiran.tambah')); ?>" type="button" class="btn btn-success mb-3">Tambah Absensi</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="iq-card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nomor Peserta</th>
                                    <th>Nama Siswa</th>
                                    <th>Asal Sekolah</th>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($kehadirans) === 0): ?>
                                    <tr>
                                        <td style="text-align: center;" colspan="6">Tidak ada siswa yang tidak berangkat</td>
                                    </tr>
                                <?php elseif(count($kehadirans) > 0): ?>

                                <?php ($no = 1); ?>
                                <?php $__currentLoopData = $kehadirans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kehadiran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($no++); ?></th>
                                    <th><?php echo e($kehadiran->no_peserta); ?></th>
                                    <th><?php echo e($kehadiran->name); ?></th>
                                    <th><?php echo e($kehadiran->nama_sekolah); ?></th>
                                    <th><?php echo e($kehadiran->keterangan); ?></th>
                                    <th>
                                        <a href="<?php echo e(route('sekolah.kehadiran.edit', $kehadiran->id)); ?>" class="btn btn-warning mb-3"><i class="ri-edit-fill pr-0"></i></a>
                                        <form action="<?php echo e(route('sekolah.kehadiran.hapus', $kehadiran->id)); ?>" method="POST" >
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button class="btn btn-danger mb-3" ><i class="ri-delete-bin-6-line"></i></button>
                                        </form>
                                    </th>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ujianku/resources/views/sekolah/kehadiran.blade.php ENDPATH**/ ?>