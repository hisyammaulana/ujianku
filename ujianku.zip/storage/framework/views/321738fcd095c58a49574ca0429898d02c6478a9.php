<?php $__env->startSection('title', 'Daftar Sekolah'); ?>
<?php $__env->startSection('page-title', 'Halaman Daftar Sekolah'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Halaman Sekolah</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hisyam/Documents/Laravel/ujianku/resources/views/cabang/cabangsekolah.blade.php ENDPATH**/ ?>