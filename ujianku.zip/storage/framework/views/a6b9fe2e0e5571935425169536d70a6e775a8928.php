<?php $__env->startSection('title', 'Tambah Siswa Tidak Ujian'); ?>
<?php $__env->startSection('page-title', 'Halaman Tambah Siswa Tidak Ujian'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12 col-lg-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Tambah Siswa Tidak Mengikuti Ujian</h4>
                    </div>
                </div>
                <div class="iq-card-body">
                    <form action="<?php echo e(route('sekolah.kehadiran.input')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="sekolah_id" value="<?php echo e(Auth::user()->id); ?>">
                        <div class="form-group">
                            <label for="no_ujian">No. Ujian Nasional</label>
                            <input type="text" class="form-control <?php if ($errors->has('no_ujian')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_ujian'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="no_ujian" name="no_ujian" autofocus>
                            <?php if ($errors->has('no_ujian')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_ujian'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="no_ujian">Nama Siswa</label>
                            <input type="text" class="form-control" id="name" name="name">
                        </div>
                        <div class="form-group">
                            <label for="no_ujian">Mata Pelajaran</label>
                            <select name="mata_pelajaran" class="form-control form-control-sm mb-3">
                                <option selected disabled>-- Pilih Palajaran --</option>
                                <option value="BAHASA INDONESIA">BAHASA INDONESIA</option>
                                <option value="MATEMATIKA">MATEMATIKA</option>
                                <option value="BAHASA INGGRIS">BAHASA INGGRIS</option>
                                <option value="KEJURUAN">KEJURUAN</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="no_ujian">Hari Ujian</label>
                            <select name="hari" class="form-control form-control-sm mb-3">
                                <option selected disabled>-- Pilih Hari --</option>
                                <option value="PERTAMA">PERTAMA</option>
                                <option value="KEDUA">KEDUA</option>
                                <option value="KETIGA">KETIGA</option>
                                <option value="KEEMPAT">KEEMPAT</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="pwd">Keterangan</label>
                            <textarea type="text" name="keterangan" class="form-control" id="keterangan"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hisyam/Documents/Laravel/ujianku/resources/views/sekolah/tambahabsen.blade.php ENDPATH**/ ?>