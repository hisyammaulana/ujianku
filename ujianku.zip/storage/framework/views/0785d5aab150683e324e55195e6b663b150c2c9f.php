<?php $__env->startSection('title', 'Daftar Siswa'); ?>
<?php $__env->startSection('page-title', 'Halaman Daftar Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Daftar Siswa </h4>
                    </div>

                </div>
                <div class="iq-card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>NISN</th>
                                    <th>Nama Siswa</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Asal Sekolah</th>
                                    <th>Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($siswa) === 0): ?>
                                <tr>
                                    <td colspan="6" style="text-align: center;">Tidak ada data siswa</td>
                                </tr>
                                <?php elseif(count($siswa) > 0): ?> <?php ($no = 1); ?> <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($siswas->nisn); ?></td>
                                    <td><?php echo e($siswas->name); ?></td>
                                    <td><?php echo e($siswas->jenis_kelamin); ?></td>
                                    <td><?php echo e($siswas->nama_sekolah); ?></td>
                                    <td><?php echo e($siswas->alamat); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ujianku/resources/views/cabang/cabangsiswa.blade.php ENDPATH**/ ?>