<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('template/images/favicon.ico')); ?>" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('template/css/bootstrap.min.css')); ?>">
    <!-- Typography CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('template/css/typography.css')); ?>">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('template/css/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('template/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.css"/>

</head>
<?php /**PATH /var/www/html/ujianku/resources/views/layouts/partials/_head.blade.php ENDPATH**/ ?>