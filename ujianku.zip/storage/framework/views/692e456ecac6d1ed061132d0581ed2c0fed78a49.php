 <?php $__env->startSection('title', 'Daftar Sekolah'); ?> <?php $__env->startSection('page-title', 'Halaman Daftar Sekolah'); ?> <?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            <div class="iq-card">
                <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                        <h4 class="card-title">Daftar Sekolah </h4>
                    </div>
                    <div class="iq-card-header-toolbar d-flex align-items-center">
                        <div class="custom-control custom-switch custom-switch-text custom-control-inline">
                            <div class="custom-switch-inner">
                                </br>
                                <a href="<?php echo e(route('cabang.tambah')); ?>" type="button" class="btn btn-success mb-3">Tambah Sekolah</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="iq-card-body">
                    <div class="table-responsive">
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Sekolah</th>
                                    <th>Email</th>
                                    <th>Username</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($sekolahs) === 0): ?>
                                <tr>
                                    <td colspan="5" style="text-align: center;">Tidak ada data siswa</td>
                                </tr>
                                <?php elseif(count($sekolahs) > 0): ?> <?php ($no = 1); ?> <?php $__currentLoopData = $sekolahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sekolah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($sekolah->name); ?></td>
                                    <td><?php echo e($sekolah->email); ?></td>
                                    <td><?php echo e($sekolah->username); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('cabang.sekolah.edit', $sekolah->id)); ?>" class="btn btn-warning mb-3"><i class="ri-edit-fill pr-0"></i></a>

                                        <form action="<?php echo e(route('cabang.sekolah.delete', $sekolah->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?> <?php echo e(method_field('DELETE')); ?>

                                            <button class="btn btn-danger mb-3"><i class="ri-delete-bin-6-line"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ujianku/resources/views/cabang/cabangsekolah.blade.php ENDPATH**/ ?>