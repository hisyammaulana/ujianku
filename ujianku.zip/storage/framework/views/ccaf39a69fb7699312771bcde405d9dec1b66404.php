<script src="<?php echo e(asset('template/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/bootstrap.min.js')); ?>"></script>
<!-- Appear JavaScript -->
<script src="<?php echo e(asset('template/js/jquery.appear.js')); ?>"></script>
<!-- Countdown JavaScript -->
<script src="<?php echo e(asset('template/js/countdown.min.js')); ?>"></script>
<!-- Counterup JavaScript -->
<script src="<?php echo e(asset('template/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/jquery.counterup.min.js')); ?>"></script>
<!-- Wow JavaScript -->
<script src="<?php echo e(asset('template/js/wow.min.js')); ?>"></script>
<!-- Apexcharts JavaScript -->
<script src="<?php echo e(asset('template/js/apexcharts.js')); ?>"></script>
<!-- Slick JavaScript -->
<script src="<?php echo e(asset('template/js/slick.min.js')); ?>"></script>
<!-- Select2 JavaScript -->
<script src="<?php echo e(asset('template/js/select2.min.js')); ?>"></script>
<!-- Owl Carousel JavaScript -->
<script src="<?php echo e(asset('template/js/owl.carousel.min.js')); ?>"></script>
<!-- Magnific Popup JavaScript -->
<script src="<?php echo e(asset('template/js/jquery.magnific-popup.min.js')); ?>"></script>
<!-- Smooth Scrollbar JavaScript -->
<script src="<?php echo e(asset('template/js/smooth-scrollbar.js')); ?>"></script>
<!-- lottie JavaScript -->
<script src="<?php echo e(asset('template/js/lottie.js')); ?>"></script>
<!-- Chart Custom JavaScript -->
<script src="<?php echo e(asset('template/js/chart-custom.js')); ?>"></script>
<!-- Custom JavaScript -->
<script src="<?php echo e(asset('template/js/custom.js')); ?>"></script>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>

<script>
    $(document).ready(function() {
    $('#example').DataTable( {
        "scrollY": 200,
        "scrollX": true
    } );
    } );
</script>
<?php /**PATH /home/hisyam/Documents/Laravel/ujianku/resources/views/layouts/partials/_script.blade.php ENDPATH**/ ?>