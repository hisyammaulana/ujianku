<?php $__env->startSection('title', 'Daftar Siswa'); ?>
<?php $__env->startSection('page-title', 'Halaman Daftar Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Halaman Kehadiran</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ujianku/resources/views/cabang/cabangkehadiran.blade.php ENDPATH**/ ?>